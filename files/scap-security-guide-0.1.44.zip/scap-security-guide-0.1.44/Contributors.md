<!---This file is generated using the contributors.py script. DO NOT MANUALLY EDIT!!!!
Last Modified: 2019-05-03 14:39
--->

The following people have contributed to the SCAP Security Guide project
(listed in alphabetical order):

* Frank J Cameron (CAM1244) <cameron@ctc.com>
* 0x66656c6978 <0x66656c6978@users.noreply.github.com>
* Gabe Alford <redhatrises@gmail.com>
* Firas AlShafei <firas.alshafei@us.abb.com>
* Christopher Anderson <cba@fedoraproject.org>
* angystardust <angystardust@users.noreply.github.com>
* Chuck Atkins <chuck.atkins@kitware.com>
* Ryan Ballanger <root@rballang-admin-2.fastenal.com>
* Alex Baranowski <alex@euro-linux.com>
* Molly Jo Bault <Molly.Jo.Bault@ballardtech.com>
* Gabriel Becker <ggasparb@redhat.com>
* Alexander Bergmann <abergmann@suse.com>
* Jose Luis BG <bgjoseluis@gmail.com>
* Joseph Bisch <joseph.bisch@gmail.com>
* Jeffrey Blank <blank@eclipse.ncsc.mil>
* Olivier Bonhomme <ptitoliv@ptitoliv.net>
* Ted Brunell <tbrunell@redhat.com>
* Blake Burkhart <blake.burkhart@us.af.mil>
* Patrick Callahan <pmc@patrickcallahan.com>
* Nick Carboni <ncarboni@redhat.com>
* James Cassell <james.cassell@ll.mit.edu>
* Frank Caviggia <fcaviggi@ra.iad.redhat.com>
* Eric Christensen <echriste@redhat.com>
* Caleb Cooper <coopercd@ornl.gov>
* Deric Crago <deric.crago@gmail.com>
* Maura Dailey <maura@eclipse.ncsc.mil>
* Klaas Demter <demter@atix.de>
* dhanushkar-wso2 <dhanushkar@wso2.com>
* Andrew DiPrinzio <andrew.diprinzio@jhuapl.edu>
* Jean-Baptiste Donnette <jean-baptiste.donnette@epita.fr>
* drax <applezip@gmail.com>
* Greg Elin <gregelin@gitmachines.com>
* Leah Fisher <lfisher047@gmail.com>
* Alijohn Ghassemlouei <alijohn.ghassemlouei@sapns2.com>
* Andrew Gilmore <agilmore2@gmail.com>
* Joshua Glemza <jglemza@nasa.gov>
* Loren Gordon <lorengordon@users.noreply.github.com>
* Patrik Greco <sikevux@sikevux.se>
* Steve Grubb <sgrubb@redhat.com>
* Marek Haicman <mhaicman@redhat.com>
* Rebekah Hayes <rhayes@corp.rivierautilities.com>
* Trey Henefield <thenefield@gmail.com>
* Henning Henkel <henning.henkel@helvetia.ch>
* hex2a <hex2a@users.noreply.github.com>
* John Hooks <jhooks@starscream.pa.jhbcomputers.com>
* Robin Price II <robin@redhat.com>
* Jeremiah Jahn <jeremiah@goodinassociates.com>
* Stephan Joerrens <Stephan.Joerrens@fiduciagad.de>
* Jono <jono@ubuntu-18.localdomain>
* Kai Kang <kai.kang@windriver.com>
* Charles Kernstock <charles.kernstock@ultra-ats.com>
* Yuli Khodorkovskiy <ykhodorkovskiy@tresys.com>
* Lee Kinser <lee.kinser@gmail.com>
* Peter 'Pessoft' Kolínek <github@pessoft.com>
* Luke Kordell <luke.t.kordell@lmco.com>
* Malte Kraus <malte.kraus@suse.com>
* kspargur <kspargur@kspargur.csb>
* Amit Kumar <amitkuma@redhat.com>
* Fen Labalme <fen@civicactions.com>
* Ian Lee <lee1001@llnl.gov>
* Jarrett Lee <jarrettl@umd.edu>
* Jan Lieskovsky <jlieskov@redhat.com>
* Šimon Lukašík <slukasik@redhat.com>
* Milan Lysonek <mlysonek@redhat.com>
* Fredrik Lysén <fredrik@pipemore.se>
* Matus Marhefka <mmarhefk@redhat.com>
* Jamie Lorwey Martin <jlmartin@redhat.com>
* Michael McConachie <michael@redhat.com>
* Khary Mendez <kharyam@gmail.com>
* Rodney Mercer <rmercer@harris.com>
* Matt Micene <nzwulfin@gmail.com>
* Brian Millett <bmillett@gmail.com>
* Mixer9 <35545791+Mixer9@users.noreply.github.com>
* mmosel <mmosel@kde.example.com>
* Zbynek Moravec <zmoravec@redhat.com>
* Kazuo Moriwaka <moriwaka@users.noreply.github.com>
* Michael Moseley <michael@eclipse.ncsc.mil>
* Joe Nall <joe@nall.com>
* Neiloy <neiloy@redhat.com>
* Axel Nennker <axel@nennker.de>
* Michele Newman <mnewman@redhat.com>
* Sean O'Keeffe <seanokeeffe797@gmail.com>
* Ilya Okomin <ilya.okomin@oracle.com>
* Kaustubh Padegaonkar <theTuxRacer@gmail.com>
* Michael Palmiotto <mpalmiotto@tresys.com>
* Max R.D. Parmer <maxp@trystero.is>
* pcactr <paul.c.arnold4.ctr@mail.mil>
* Kenneth Peeples <kennethwpeeples@gmail.com>
* Nathan Peters <Nathaniel.Peters@ca.com>
* Frank Lin PIAT <fpiat@klabs.be>
* Stefan Pietsch <mail.ipv4v6+gh@gmail.com>
* Martin Preisler <mpreisle@redhat.com>
* Wesley Ceraso Prudencio <wcerasop@redhat.com>
* Raphael Sanchez Prudencio <rsprudencio@redhat.com>
* T.O. Radzy Radzykewycz <radzy@windriver.com>
* Kenyon Ralph <kenyon@kenyonralph.com>
* Rick Renshaw <Richard_Renshaw@xtoenergy.com>
* Chris Reynolds <c.reynolds82@gmail.com>
* rhayes <rhayes@rivierautilities.com>
* Pat Riehecky <riehecky@fnal.gov>
* rlucente-se-jboss <rlucente@redhat.com>
* Joshua Roys <roysjosh@gmail.com>
* rrenshaw <bofh69@yahoo.com>
* Chris Ruffalo <chris.ruffalo@gmail.com>
* Ray Shaw (Cont ARL/CISD) rvshaw <rvshaw@esme.arl.army.mil>
* Willy Santos <wsantos@redhat.com>
* Gautam Satish <gautams@hpe.com>
* Watson Sato <wsato@redhat.com>
* Satoru SATOH <satoru.satoh@gmail.com>
* Alexander Scheel <ascheel@redhat.com>
* Spencer Shimko <sshimko@tresys.com>
* Thomas Sjögren <konstruktoid@users.noreply.github.com>
* Francisco Slavin <fslavin@tresys.com>
* David Smith <dsmith@eclipse.ncsc.mil>
* Kevin Spargur <kspargur@redhat.com>
* Kenneth Stailey <kstailey.lists@gmail.com>
* Leland Steinke <leland.j.steinke.ctr@mail.mil>
* Brian Stinson <brian@bstinson.com>
* Philippe Thierry <phil@reseau-libre.net>
* Paul Tittle <ptittle@cmf.nrl.navy.mil>
* tomas.hudik <tomas.hudik@embedit.cz>
* Jeb Trayer <jeb.d.trayer@uscg.mil>
* Matěj Týč <matyc@redhat.com>
* VadimDor <29509093+VadimDor@users.noreply.github.com>
* Shawn Wells <shawn@redhat.com>
* Daniel E. White <linuxdan@users.noreply.github.com>
* Roy Williams <roywilli@roywilli.redhat.com>
* Rob Wilmoth <rwilmoth@redhat.com>
* Lucas Yamanishi <lucas.yamanishi@onyxpoint.com>
* Xirui Yang <xirui.yang@oracle.com>
* Kevin Zimmerman <kevin.zimmerman@kitware.com>
* Jan Černý <jcerny@redhat.com>
* Michal Šrubař <msrubar@redhat.com>
